# Mini Aplicação Web – Login, Sessões, Cookies e Tema Persistente

Este projeto é uma mini aplicação web desenvolvida com HTML, CSS e JavaScript puro, criada para demonstrar conceitos essenciais de autenticação simples, gerenciamento de sessões, uso de cookies e práticas básicas de segurança em aplicações front-end.

Ele simula uma área autenticada, onde o usuário realiza login, tem suas informações armazenadas temporariamente na sessão e pode personalizar o tema da interface (claro/escuro), com a preferência sendo mantida mesmo após recarregar a página.

O objetivo é mostrar domínio de manipulação do DOM, validação de formulários, controle de acesso e persistência de dados no navegador, sem utilizar frameworks nem backend.

## Objetivos de Aprendizado
- Aplicar validações reais em formulários.
- Criar e gerenciar sessões usando sessionStorage.
- Gravar preferências do usuário com cookies.
- Implementar proteção de rota no front-end.
- Desenvolver uma UI simples, funcional e responsiva com HTML e CSS.
- Tratar fluxo de logout e limpeza de dados persistidos.

## Tecnologias Utilizadas
- HTML5
- CSS3
- JavaScript (Vanilla JS)
- sessionStorage
- Cookies

## Principais Funcionalidades
### 1. Tela de Login com Validação
- Validação de email com regex.
- Senha mínima de 6 caracteres.
- Impede envio com campos vazios.
- Salva sessão no sessionStorage.

### 2. Área Autenticada com Proteção de Rota
- Redireciona para login se a sessão não existir.
- Exibe email do usuário logado.

### 3. Tema com Cookies
- Tema claro/escuro.
- Preferência armazenada em cookie com duração de 1 ano.

### 4. Logout
- Limpa sessionStorage.
- Apaga cookies.
- Redireciona para login.

## Arquivos do Projeto
- index.html
- pagina-logada.html
- style.css
- script.js

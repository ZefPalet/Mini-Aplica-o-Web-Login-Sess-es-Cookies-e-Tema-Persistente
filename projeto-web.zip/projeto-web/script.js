// --------------- LOGIN ---------------
if (document.getElementById("loginForm")) {
    document.getElementById("loginForm").addEventListener("submit", function(e) {
        e.preventDefault();

        const email = document.getElementById("email").value.trim();
        const senha = document.getElementById("senha").value.trim();
        const erro = document.getElementById("erro");

        if (!email || !senha) {
            erro.textContent = "Nenhum campo pode ficar vazio!";
            return;
        }

        const emailValido = /\S+@\S+\.\S+/.test(email);
        if (!emailValido) {
            erro.textContent = "Email inválido!";
            return;
        }

        if (senha.length < 6) {
            erro.textContent = "A senha deve ter no mínimo 6 caracteres!";
            return;
        }

        sessionStorage.setItem("email", email);
        window.location.href = "pagina-logada.html";
    });
}

// --------------- ÁREA LOGADA ---------------
if (window.location.pathname.includes("pagina-logada.html")) {

    const email = sessionStorage.getItem("email");
    if (!email) {
        window.location.href = "index.html";
    }

    document.getElementById("bemvindo").textContent = "Usuário logado: " + email;

    const temaSalvo = document.cookie.replace("tema=", "");
    if (temaSalvo === "dark") document.body.className = "dark";
    else document.body.className = "light";

    document.getElementById("temaClaro").onclick = () => {
        document.body.className = "light";
        document.cookie = "tema=light; path=/; max-age=31536000";
    };

    document.getElementById("temaEscuro").onclick = () => {
        document.body.className = "dark";
        document.cookie = "tema=dark; path=/; max-age=31536000";
    };

    document.getElementById("logout").onclick = () => {
        sessionStorage.clear();
        document.cookie = "tema=; path=/; max-age=0";
        window.location.href = "index.html";
    };
}